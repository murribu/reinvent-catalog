Session Type Ids

Workshop = 1000
Spotlight Lab = 1780
Session = 2
Lightning Talk = 1440
Hackathon = 1040
Demo Session = 1560
Chalk Talk = 1700
Builders Session = 1781
After Hours = 1921
Activity = 1920