Session Type Ids

Workshop = 2523
Spotlight Lab = 2832
Session = 2
Lightning Talk = 1440
Hackathon = 1040
Demo Session = 1560
Chalk Talk = 2623
Builders Session = 2624
After Hours = 1921
Activity = 2823
Tatonka = 3323
Hackathons and Jams = 2834
20-Minute Presentation = 2723
Dev Chat = 2828
